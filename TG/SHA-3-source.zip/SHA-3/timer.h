// Copyright (c) 2016 Quenio Cesar Machado dos Santos. All rights reserved.

#pragma once

#include <time.h>

double elapsed_secs(clock_t start);
